

def test_config(app):
    assert app.testing
